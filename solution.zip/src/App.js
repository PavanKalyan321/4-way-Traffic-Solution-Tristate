import React from 'react'
import './App.css';

const Circle =(props)=>{
  return(
    <div className="circle" style={{backgroundColor:props.color}}>
      
    </div>
  )
}

class App extends React.Component{
  state={
    Timer:0,
    signal1Color:'red',
    signal2Color:'red',
    signal3Color:'red',
    signal4:'red',
    green:'',
    yellow:'',
    red:'',
    nextColor:'',
    nextSignal:'',
    activeSignal:1,
    activeColor:'green',
    Lights:{
      'signal1Color':'red',
      'signal2Color':'red',
      'signal3Color':'red',
      'signal4':'red',
    }
  }

  

  handleStart=()=>{
    setTimeout(()=>{
      this.handleTimer1();
    },1000);
  }

  handleTimer=()=>{

  }
  setColor=(color)=>{
    this.setState({
      activeColor:color
    })
  }

  handleSignals=(signal,color)=>{
    console.log(signal,color);
    if(this.state.activeColor=='green'){
        let nextSignal=this.state.activeSignal+1;
        
    }
    if(this.state.activeColor=='yellow'){
      
    }
    if(this.state.activeColor=='red'){
      
    }
  }

  updateGreen=(signal)=>{
    this.setState({
      signal :''
    });
    setTimeout(()=>{
      this.updateYellow()
    },1000)
  }
  updateYellow=(signal)=>{
    this.setState({

    });
    setTimeout(()=>{
      this.updateRed()
    },1000)
  }
  updateRed=(signal)=>{
    setTimeout(()=>{

    },1000)
  }
  

  handleTimer1 = () => {
    console.log('in fun1 ')
    setTimeout(()=>{
      this.setState({
        signal1Color:'green',
        signal2Color:'red',
        signal3Color:'red',
        signal4:'red'
      })
      setTimeout(()=>{
        this.setState({
          signal1Color:'yellow',
          signal2Color:'red',
          signal3Color:'red',
          signal4:'red'
        })
        setTimeout(()=>{
          this.setState({
            signal1Color:'red',
            signal2Color:'green',
            signal3Color:'red',
            signal4:'red'
          })
          this.handleTimer2()
        },2000);
      },2000);
    },2000);   
  }

  handleTimer2 = () => {
    console.log('in fun 2');
    setTimeout(()=>{
      this.setState({
        signal1Color:'red',
        signal2Color:'yellow',
        signal3Color:'red',
        signal4:'red'
      })
      setTimeout(()=>{
        this.setState({
          signal1Color:'red',
          signal2Color:'red',
          signal3Color:'green',
          signal4:'red'
        })
        setTimeout(()=>{
          this.setState({
            signal1Color:'red',
            signal2Color:'red',
            signal3Color:'yellow',
            signal4:'red'
          })
          this.handleTimer3()
        },2000);
      },2000);
    },2000);
  }

  handleTimer3 = () => {
    console.log('in fun 3');
    setTimeout(()=>{
      this.setState({
        signal1Color:'red',
        signal2Color:'red',
        signal3Color:'red',
        signal4:'green'
      })
      setTimeout(()=>{
        this.setState({
          signal1Color:'red',
          signal2Color:'red',
          signal3Color:'red',
          signal4:'yellow'
        })
        setTimeout(()=>{
          this.setState({
            signal1Color:'red',
            signal2Color:'red',
            signal3Color:'red',
            signal4:'red'
          })
          this.handleTimer1()
        },2000);
      },2000);
    },2000);
  }

  // handleTimer4 = () => {
  //   console.log('in fun 4')
  //   setTimeout(()=>{
  //     this.setState({
  //       signal1Color:'green',
  //       signal2Color:'red',
  //       signal3Color:'red',
  //       signal4:'red'
  //     })
  //     setTimeout(()=>{
  //       this.setState({
  //         signal1Color:'yellow',
  //         signal2Color:'red',
  //         signal3Color:'red',
  //         signal4:'red'
  //       })
  //       setTimeout(()=>{
  //         this.setState({
  //           signal1Color:'red',
  //           signal2Color:'green',
  //           signal3Color:'red',
  //           signal4:'red'
  //         })
  //         this.handleTimer1()
  //       },2000);
  //     },2000);
  //   },2000);
    
  // }

  render(){
    return(
      <div className="App-header">
        <h3>Traffic Lights</h3>
        <button onClick={this.handleStart}>Start</button>
     Signal 1{" "}   <Circle color={this.state.signal1Color} /><br/>
     Signal 2{" "}    <Circle color={this.state.signal2Color} /><br/>
     Signal 3{" "}    <Circle color={this.state.signal3Color} /><br/>
     Signal 4{" "}    <Circle color={this.state.signal4} /><br/>
     
      </div>  
    )
  }
}

export default App;
